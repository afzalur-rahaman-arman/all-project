<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");
  }
?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Orders</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white;">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custS.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
   <a class="navbar-brand" href="order.php">Order</a>
   <a class="navbar-brand" href="bill.php">Accepted Bill</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>

  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>
</nav>

<br>
<br>

<br>

<CENTER>
	<table class="table" border="0px">
	<div class="jumborton-text-center">

<form action="Order.php" method="POST" class="form-inline">
	<div class="form-group">
		<br>
		<tr>
			<th>
	<LABEL for='t'>Total newspaper  </LABEL></th>
	<th>
	<input type="number" name="num" class="form-control" id="t">
</th>
</tr>
</div>
<br>
<tr>
	<th>
<div class="form-group">
	<label for='n'>Newsname     </label>
</th>
<th>
<input type="text" name="n" class="form-control" id='n'>

</div>
</th>
</tr>
<br>
<tr>
	<th></th>
	<th>
<div class="form-group">
<button class="btn btn-success" type="submit" value="submit" name='submit'>Send Request?</button>

</div>
</th>
</tr>
</div>
</table>

</form>

</CENTER>

<br>

<div class="btn btn-success">
	<?php

$conn=mysqli_connect("localhost", 'root', '', "news");
$num = 0;
$n='';
if (isset($_POST['submit'])) {
	$num=$_POST["num"];
	$news=$_POST['n'];

$email=$_SESSION["email"];
$name="";
$phonenumber="";
$address="";
  $n=$_POST["n"];
$S="select * from customer where email='$email'";
$result=$conn->query($S);
if ($result->num_rows>0) {
  while($row=$result->fetch_assoc())
  {
$name=$row["id"];
$phonenumber=$row["phoneNumber"];
$address=$row["address"];
  }
}

$total=$num*4;

	$sq="insert into orders(num, news, name, phonenumber, email, address, total) values ('$num', '$news', '$name','$phonenumber', '$email', '$address', '$total')";
	if (mysqli_query($conn, $sq)) {
		echo "Total : <i style='color:red'>".$total."/-</i>";
		echo "<br>Your request succesfully sent.
		Now sent <b style='color:red'>".$total."/-</b> to <a href='#'>+880 1533551939 <a>";
	}

}

?>

	</div>

  <br>
  <br>

  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>

