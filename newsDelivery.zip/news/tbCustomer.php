<?php

$conn = mysqli_connect("localhost","root",'', "news");

$sql="create table customer(

id varchar(100) not null,
email varchar(100) not null,
address varchar(100) not null,
phoneNumber varchar(100) not null,
password varchar(100) not null
)";


if (mysqli_query($conn,$sql)) {
	echo "Sucessfull";
}

else
echo "Try again";

$conn->close();

?>