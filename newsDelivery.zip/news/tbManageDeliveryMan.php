
CREATE TABLE `deliveryMan` (
`nName` varchar(100) NOT NULL,
`dName` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phonenumber` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

