<!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>

<body style="background-color: #00FA9A">
​
<nav class="topnav">
  <a class="navbar-brand" href="index.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
  <a class="navbar-brand" href="login.php">Login</a>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</nav>
​





<div class="container">
  <h2>Register</h2>
  <br>
  <br>
  <form action="#">

    <div class="form-group">
      <label for="Name">Name</label>
      <input type="text" name="name" class="form-control" placeholder="Enter Your Name">
    </div>

    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
      <label for="email">Password</label>
      <input type="Password" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>

    <div class="form-group">
      <label for="Name">Address</label>
      <input type="text" name="name" class="form-control" placeholder="Enter Your Address ">
    </div>
     <div class="form-group">
      <label for="Name">Postcode</label>
      <input type="text" name="pcode" class="form-control" placeholder="Enter Your Postcode ">
    </div>

     <div class="form-group">
      <label for="Name">Phone Number</label>
      <input type="text" name="pnum" class="form-control" placeholder="Enter Your Phone Number">
    </div>

    <button type="submit" class="btn btn-success">Send</button>
    Already registered? <a href="#">Sign in</a> 
  </form>
</div>


 
  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">



<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">paky.yuvraj@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>