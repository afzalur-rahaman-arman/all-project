<?php
session_start();
$id = "";
$email    = "";
$errors = array(); 
$db =mysqli_connect("localhost","root",'',"news");

if (isset($_POST['reg_user'])) {
  $id = mysqli_real_escape_string($db, $_POST['name']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password1 = mysqli_real_escape_string($db, $_POST['password1']);
  $password2 = mysqli_real_escape_string($db, $_POST['password2']);
  if (empty($id)) { array_push($errors, "Name is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password1)) { array_push($errors, "Password is required"); }
  if ($password1 != $password2) {
  array_push($errors, "The two passwords do not match");
  }



  $user_check_query = "SELECT * FROM customer WHERE email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if customer exists
    if ($user['id'] === $id) {
      array_push($errors, "Name already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "Email already exists");
    }
  }

  if (count($errors) == 0) {
    $password1 = md5($password1);
    $address=$_POST['address'];
    $phoneNumber=$_POST['phoneNumber'];
    $query = "INSERT INTO customer (id, email,address, phoneNumber, password) 
          VALUES('$id', '$email', '$address','$phoneNumber','$password1')";
    mysqli_query($db, $query);
    $_SESSION['email'] = $email;
    $_SESSION['success'] = "You are now logged in.";
    header('location:customer.php');
  }
}

if (isset($_POST['login_user']) ) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password1 = mysqli_real_escape_string($db, $_POST['password1']);
$e=$_POST['email'];
  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($password1)) {
    array_push($errors, "Password is required");
  }


  if (count($errors) === 0) {
    $password1 = md5($password1);
    $query = "SELECT * FROM customer WHERE email='$email'";
    if (mysqli_query($db, $query)) {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in."; 
      header('location:customer.php');
}
}
}

?>

<!-- // if (isset($_POST['reg_user'])) {
//   if ($p1!=$p2) {
//     array_push($errors,"Password not matched.");
//   }
//   else
//   {
//   $p1=md5($p1);
//   $sql="select from customer where id='$n'";
//   $result=mysqli_query($conn, $sql);

//   if (!$result) {
//     if (mysqli_num_rows($result)) {
//       $row=mysqli_fetch_assoc($result);
//       if ($row["id"]!='$n') {
//         $sql="insert into customer(id, email, password) values('$n', '$e','$p1') ";
//         $result=mysqli_query($conn, $sql);
//         if ($result) {
//           header('location:customerLogin.php');
//         }
//       }
      
//     }
//   }
//   }
// }
 -->

<!-- if (isset($_POST["reg_user"])) {
  if ($p1!=$p2) {
    array_push( $errors , "Password not matched");
  }
  $p1=md5($p1);
  $sql="select from customer where id='$n' and password='$p1' limit 1";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result))
  {
      $row=mysqli_fetch_assoc($result);
      if($row['id']==$n)
      {
        array_push($errors, "The name is already used");
      }
      else
      {
        $sql1="insert into customer(id, email, password) values ('$n', '$p1', '$e')";
    if (mysqli_query($conn, $sql1)) {
      header('location: customerLogin.php');
    }
      }
  } -->