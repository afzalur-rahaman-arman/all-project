<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");
  }
?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white;">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custS.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
  
   <a class="navbar-brand" href="order.php">Order</a>
   <a class="navbar-brand" href="bill.php">Accepted Bill</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>
  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>
</nav>

<br>
<br>
 
<center>

 <?php

$conn=mysqli_connect("localhost", "root", '', "news");
$email=''; 
$sql="select * from images";
    $email=$_SESSION['email'];
    
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "
<table class='table table-responsive' border='0px'>
  <tr>
    <th>";
      echo "<img src='".$row['image']."' width='100' height='60'>";
    echo "</th>
    <th>";

    $nn=$row['newsname'];
  echo "  <form method='POST' action='viewSubscribe.php'>";
  echo "<input type='text' name='n' value='$nn'>";
 echo " </th>";
 echo " <th>";
echo "<button type='submit'class=' btn btn-danger'>Subscribe</button>";
 echo " </th>";
 echo "</form>";
    echo "</th>";

echo '  </tr>
</table>';

  }
}
?>






<?php


$conn=mysqli_connect("localhost", "root", '', "news");
if (isset($_POST["n1"])) {
  $email=$_SESSION["email"];
   $n1=$_POST["n1"];

// $insert="insert into alterSubscriber(name, email,phonenumber, address) values('$name', $email','$phonenumber') "

  $d="delete from subscription where newsname='$n1' AND email='$email'";
  if (mysqli_query($conn, $d)) {
    echo "Unsubscribe Successfull";
  }
  else
  {
    echo "Failed";
  }
}

?>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>

  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>

<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>









<!-- 
<a href="get.php?l=afzal" style="color: red;">Logout</a>
<?php

if(isset($_GET['l']))
{
  echo $_GET['l'],'ur';
}

?>



<?php
$mysqli = new mysqli("localhost", "root", "", "news");
if($mysqli->connect_error) {
  exit('Could not connect');
}

$sql = "SELECT email
FROM users WHERE id = 'admin' ";

$stmt = $mysqli->prepare($sql);
//$stmt->bind_param("s", $_GET['q']);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($email);
$stmt->fetch();
$stmt->close();

echo "<table>";
echo "<tr>";
echo "<th>CustomerID</th>";
echo '</tr>';
echo '<tr>';
echo "<td>" . $email . "</td>";

echo "</table>";
?> -->


