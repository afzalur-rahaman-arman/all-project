

<a href="get.php?l=afzal" style="color: red;">Logout</a>
<?php

if(isset($_GET['l']))
{
	echo $_GET['l'],'ur';
}

?>