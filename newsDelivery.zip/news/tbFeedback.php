<?php

$conn= mysqli_connect("localhost", "root", '',"news");

$sql="create table feedback(

name varchar(30) not null, 
feed varchar(1000) not null

)";

if(mysqli_query($conn, $sql))
echo " feedback Table create successfull";
else
echo "Failed. Try Again";

?>