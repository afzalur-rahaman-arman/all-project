<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");
  }
?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Orders</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white;">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custS.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
   <a class="navbar-brand" href="order.php">Order</a>
   <a class="navbar-brand" href="bill.php">Accepted Bill</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>

  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>
</nav>

<br>
<br>

<br>
<br>
<br>
<!-- <center>
<?php

$conn=mysqli_connect("localhost", "root", '', "news");


if(isset($_POST['name']))
{
  $name=$_POST["name"];
$feedback=$_POST["feedback"];
$sql="insert into feedback(name, feed) values('$name', '$feedback')";
if (mysqli_query($conn, $sql)) {
  echo "Thanks for your opinion";
}
}
else
 // echo "Enter Your Name Please";

?>
​
<div class="container">
  <h2>Send Feedback</h2>
  <br>
  <br>

  <form action="userFeedback.php" method="POST">

<input type="text" name="name" placeholder="Name">
<BR>
<br>
<textarea name="feedback" value="submit" type="text" placeholder="Feedback">
</textarea>

<br>
    <button type="submit" class="btn btn-success" value="submit">Send</button>
  </form>
</div>

</center> -->



<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center">Feedback</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Dhaka, Bangladesh</p>
      <p><span class="glyphicon glyphicon-phone"></span> +880 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span> faria.cse.bgctub@gmail.com</p>
    </div>
    <?php

$conn=mysqli_connect("localhost", "root", '', "news");


if(isset($_POST['name']))
{
  $name=$_POST["name"];
$feedback=$_POST["feedback"];
$sql="insert into feedback(name, feed) values('$name', '$feedback')";
if (mysqli_query($conn, $sql)) {
  echo "Thanks for your opinion";
}
}
else
 // echo "Enter Your Name Please";

?>
​
<div class="container">
  <br>
  <br>

  <form action="userFeedback.php" method="POST">
    <div class="col-sm-7 slideanim">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email">
        </div>
      </div>
      <textarea class="form-control" id="comments" name="feedback" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit" value="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>
</form>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>

</footer>


</body>
</html>





<br>
<br>
<br>

 
  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">



<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>