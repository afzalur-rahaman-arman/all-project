<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white;">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custS.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
  
   <a class="navbar-brand" href="order.php">Order</a>
   <a class="navbar-brand" href="bill.php">Accepted Bill</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>
  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>
</nav>

<br>
<br>

<CENTER>
<form action="viewSubscribe.php" method="POST">
  <input type="text" name="un">
 <button name='s' type="submit" value="submit">Unsubscribe</button>
</form>
</CENTER>
<!-- 
<?php
// $count=0;
// $conn=mysqli_connect("localhost", "root", '', "news");

// if (isset($_POST["n"])) {

// $email=$_SESSION["email"];
// echo $email.'aaaa';


// $name="";
// $phonenumber="";
// $address="";

//   $n=$_POST["n"];
// $S="select * from customer where email='$email' limit '1' ";
// $result=$conn->query($S);
// if ($result->num_rows>0) {
//   while($row=$result->fetch_assoc())
//   {
// $name=$row["id"];
// $phonenumber=$row["phoneNumber"];
// $address=$row["address"];
//   }
// }

// $e1='';
// $ne1='';
// $S="select * from subscription where email='$email'";
// $result=$conn->query($S);
// if ($result->num_rows>0) {
//   while($row=$result->fetch_assoc())
//   {
// $e1=$row["email"];
// $ne1=$row["newsname"];

// $sql="select * from images where newsname='$ne1'";
   
// $r = $conn->query($sql);
// if ($r->num_rows > 0) {
//   while($row = $r->fetch_assoc()) {
//     echo "Subscriber List<hr>";
//     echo "
// <table class='table table-responsive' border='0px'>
//   <tr>
//     <th>";
//       echo "<img src='".$row['image']."' width='100' height='60'>";
//     echo "</th>
//     <th>";
//     $nn=$row['newsname'];
//     echo $nn;
//     echo "</th>
//   </tr>
// </table>";
//   }
// }

//     $select="select newsname, email from subscription where newsname='$n' and email='$email' limit 1";
//     if ($e1===$email && $ne1===$n) {
//       $count=1;
//     }
//     else
//     {
//       if ($count==0) {
       

//       $sqs="insert into subscription(name,newsname,phonenumber,email,address) values('$name','$n','$phonenumber','$email','$address')";
    
//     if (mysqli_query($conn, $sqs)) {
//       echo "Welcome!  Subscribe Successfull";
//       break;
//     }
//     }
//   }
// }
// }  
// }


//?> -->


<?php
$count=0;
$conn=mysqli_connect("localhost", "root", '', "news");

$email=$_SESSION["email"];

if (isset($_POST["n"])) {//-----------------insert process start----------------//
$n=$_POST["n"];

$name="";
$phonenumber="";
$address="";


$S="select * from customer where email='$email' limit 1 ";
$result=$conn->query($S);
if ($result->num_rows>0) {
  while($row=$result->fetch_assoc())
  {
$name=$row["id"];
$phonenumber=$row["phoneNumber"];
$address=$row["address"];

  }
}

$n1="";
$select="select * from subscription where newsname = '$n' and email = '$email'";

  $result= $conn->query($select);
  if($result->num_rows>0)
  {
    while($row=$result->fetch_assoc())
    {
      $n1=$row["newsname"];
    }
  }

if($n!=$n1)
{

$insert="insert into subscription(name, newsname, phonenumber, email, address) values('$name', '$n', '$phonenumber', '$email', '$address') ";

if(mysqli_query($conn,$insert))
{
  echo 'Subscribed...!';
}
}


}//-----------------insert process end--------------//


$newsname='';
$c=0;

$S="select * from subscription where email='$email' ";
$result=$conn->query($S);
$c=$result->num_rows;

     echo "<table class = 'table table-responsive table-stripe'>";
     echo "<tr><th>Image </th>";
     echo "<th>Newspaper </th>";
     echo "<th>Status</th>";
     

     echo "</tr>";

echo '<br><br>Total subscribed newspaper :<b> '.$c.'</b><br><br>';
$i=0;
while($c!=0)
{

  $S="select * from subscription where email='$email'";
$result=$conn->query($S);
if ($result->num_rows>0) {
  while($row=$result->fetch_assoc())
  {
$newsname=$row["newsname"];


$S="select * from images where newsname='$newsname' ";
 $re= $conn->query($S);
 if($re->num_rows>0)
 {
  while($row=$re->fetch_assoc())
  {
    echo "<tr>"; 
     echo "<td > ";
    echo "<img src='".$row['image']."' width='100' height='50'>";//----image print----//
    echo "</td>";
    echo '<td>';
    $nn= $row['newsname'];


    echo "  <form method='POST' action='viewSubscribe.php'>";
  echo "<input type='text' name='un' value='$nn'>";
 echo " </td>";
 echo " <td>";
echo "<button type='submit'class=' btn btn-danger'>Unsubscribe</button>";
 echo " </td>";
 echo "</form>";



// echo "<form method = 'POST' action ='viewSubscribe.php'";

//   $_SESSION['u']=array();
//     echo "<button class = 'btn btn-danger' name ='". 'u'.$newsname; echo "'>Unsubscribe"; 
//     $a=array($newsname);
  

//    // array_splice($_SESSION['u'], $c, 0, $a);
//     array_push($_SESSION['u'], $newsname);


echo '</tr>';



  }
 }

$c--;
}}
}

echo '</table>';




// $d="delete from subscription where email='email'";
// if(mysqli_query($conn, $d))
//   echo 'successfull';


?>


<?php



$conn= mysqli_connect("localhost", 'root', '', 'news');
$email=$_SESSION["email"];

if(isset($_POST['un']))

{

  $un=$_POST['un'];
  $d="delete from subscription where email = '$email' and newsname='$un'";


  if(mysqli_query($conn, $d))
  {
    echo $un;
    echo " newspaper successfully unsubscribed..!";
  }
}

?>



</center>

  <br>
  <br><br>
  <br><br>
  <br>
<br>
  <br>
  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>


