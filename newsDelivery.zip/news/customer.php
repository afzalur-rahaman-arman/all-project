<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");   
  }
?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Orders</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white;">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custS.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
   <a class="navbar-brand" href="order.php">Order</a>
   <a class="navbar-brand" href="bill.php">Accepted Bill</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>

  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>
</nav>

<br>
<br>

<br>

<br>
<br>

<br>
<br>
<center>
 <?php
$conn=mysqli_connect("localhost", "root", '', "news");
$e=$_SESSION['email'];
$sql="select * from customer where email='$e' ";
$result = $conn->query($sql);
if ($result) {

$sql="select * from customerimage where customername='$e'";
$result1 = $conn->query($sql);
if ($result1->num_rows) {
    $row = $result1->fetch_assoc(); 
    echo "Now You are logged in<br>";

     echo "<img src='".$row['image']."'"." width='100' height='100'>";//----image print----//

     echo "<hr>";
}
else
{
  echo " <form method='post' enctype='multipart/form-data'>
<table align='center'>
  <TR>
    <TH align='center'><u><i><h6>Change Your Image</h6></i></u></TH>
  </TR>
 
  <tr>
    <th>
      Image
    </th>
    <th>
      <input type='file' name='file' />
    </th>
  </tr>
  <tr><td></td><td><input type='submit' value='Save Image' name='but_upload'> </td></tr>
</table>
    </form>";
}

    echo "<br>";
    echo "<table class='table'>";
if ($result->num_rows > 0) {

   while($row = $result->fetch_assoc())
   {


 echo "<tr><th>Name : ".$row['id']."</th>";echo "</tr>";
 echo "<tr><th>Email id : <a href='#'>".$row['email']."</a></th>";echo "</tr>";
 echo "<tr><th>Phone Number : ".$row['phoneNumber'];echo "</tr>";
 echo "<tr></th><th>Address : ".$row['address'];echo "</tr>";

   } 

}

echo "</table>";


}

 ?>
</center>

<br>
<br>

    <?php
    include("config.php");
  $customername= $_SESSION["email"];
  
    if(isset($_POST['but_upload'])){
        $name = $_FILES['file']['name'];
        $target_dir = "upload1/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);

        // Select file type
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Valid file extensions
        $extensions_arr = array("jpg","jpeg","png","gif");

        // Check extension
        if( in_array($imageFileType,$extensions_arr) ){
            
            // Convert to base64 
            $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']) );
            $image = 'data:image/'.$imageFileType.';base64,'.$image_base64;

            // Insert record
            $query = "insert into customerimage(customername,name,image) values('$customername','".$name."','".$image."')";
           
            mysqli_query($con,$query) or die(mysqli_error($con));
            
            // Upload file
            move_uploaded_file($_FILES['file']['tmp_name'],'upload1/'.$name);

        }
    
    }
    ?>




   

  <br>
  <br>

  <br>
  <br>

  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>
</body>
</html>