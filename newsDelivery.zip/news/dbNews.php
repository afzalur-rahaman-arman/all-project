<?php

$conn=mysqli_connect("localhost", "root", '');
$sql="create database news";
if (mysqli_query($conn, $sql)) {
	echo "news db create successfull";
}
else
echo "Try again";

?>