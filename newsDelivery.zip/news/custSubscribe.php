<?php 
  session_start(); 

  if (!(isset($_SESSION['email']))) {
   $_SESSION['msg'] = "You must log in first";
 
    header("location: customerLogin.php");
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header("location: home.php");
  }
?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: white">

<nav class="topnav">
  <a class="navbar-brand" href="customer.php">Home</a>
  <a class="navbar-brand" href="custSubscribe.php">Subscribe Newspaper</a>
  <a class="navbar-brand" href="viewSubscribe.php">View Subscribe</a>
  <a class="navbar-brand" href="profile.php">Profile</a>
  <a class="navbar-brand" href="userFeedback.php">Feedback</a>
  <a class="navbar-brand" href="home.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>

  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</nav>

<br>
<br>

<br>
<br>
<center>

 <?php

$conn=mysqli_connect("localhost", "root", '', "news");
$email='';
$sql="select * from images";
    $email=$_SESSION['email'];
    
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "
<table class='table table-responsive' border='0px'>
	<tr>
		<th>";
			echo "<img src='".$row['image']."' width='100' height='60'>";
		echo "</th>
		<th>";
    $nn=$row['newsname'];
		echo $nn;
		echo "</th>
		<th>
			<form action='custSubscribe.php' method='POST'>";
		echo "<button type='submit' name='";
$ssn="select email, newsname from subscription where email='$email' and newsname='$nn'";
$R=$conn->query($ssn);
$n='';
$e='';
if ($R->num_rows>0) {
  while ($row=fetch_assoc()) {
    $n=$row["newsname"];
    $e=$row["email"];
  }
}
$n1='';
if ($R) {
  $n1='news1';
  echo $n1;
}
else
{
  $n1='news';
  echo $n1;
}
     echo "'class='btn btn-danger' value='".$nn."'>";
if ($n1==="news") {
  echo "Unsubscribe";
}
else
{
  echo "Subscribe";
}
    echo "</button>" ."
			</form>
		</th>
	</tr>
</table>";

  }
}

?>
<?php
session_start();

$conn=mysqli_connect("localhost", "root", '', "news");
echo $_POST['news1'];
echo $_POST['news'];
if (isset($_POST["news1"])) {
$email=$_SESSION["email"];
$name="";
$phonenumber="";
$address="";
  $newsname=$_POST["news1"];
$S="select * from customer where email='$email'";
$result=$conn->query($S);
if ($result->num_rows>0) {
  while($row=$result->fetch_assoc())
  {
$name=$row["id"];
$phonenumber=$row["phoneNumber"];
$address=$row["address"];
  }
}

  $ss="select * from subscription where email='$email' and newsname='$newsname' and phonenumber='$phonenumber'";
  if (mysqli_query($conn, $ss)) {

    $sqs="insert into subscription(name,newsname,phonenumber,email,address) values('$name','$newsname','$phonenumber','$email','$address')";
    if (mysqli_query($conn, $sqs)) {
      echo "Welcome!  Subscribe Successfull";
    }
  }
    else
    {

    echo "Already Subscribed";
  }
}

if (isset($_POST["news"])) {
  $nd=$_POST["news"];
  $d="delete * from subscription where newsname='$nd'";
  if (mysqli_query($conn, $d)) {
    echo "Unsubscribe Successfull";
  }
}


?>
</center>
  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">paky.yuvraj@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>
