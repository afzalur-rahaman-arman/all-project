<!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: #00FA9A">

<nav class="topnav">
  <a class="navbar-brand" href="home.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
  <a class="navbar-brand" href="loginpage.php">Login</a>

  <a class="navbar-brand" href="userfeedback.php">Feedback</a>

  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</nav>

<br>
<br>

<br>
<br>


<center>
	<div class="container">
		<img src="paper.PNG">
	</div>
</center>

<br>
<br>

<div class="container">
	
	<div style ="background-color: #02e68e">
<h4>Created by-<br>
								<center>
									Faria</h4>
								</center>
		</center>
	</div>
</div>
<br>
<br>

  <div style="width: 500 height: 600">
    <div style="background-color: black; width: 5000; height: 5000; color: white">
<div class="container">
  <br>
  <br>
<div class="jumborton text-center">
  
  <center><b>FAQs</b></center>
  <br><center>
What is deliver my newspaper?<br>
How much does it cost?<br>
How do I pay?<br>
Do I have to get a newspaper delivered every day?<br>
How do I get my newspaper delivered?<br>
I would like to place an order by telephone</center><br>
</div>

</div>
      <hr>
      Email : <a href="#">faria.cse.bgctub@gmail.com</a> <br>
    </div>
  </div>


 
</body>
</html>