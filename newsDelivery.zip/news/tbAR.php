<?php

$conn = mysqli_connect("localhost","root",'', "news");

$sql="create table ar(
num int(100) not null, 
news varchar(100) not null,
name varchar(100) not null,
phoneNumber varchar(100) not null,
email varchar(100) not null,
address varchar(100) not null,
total int(100) not null, 

req_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";


if (mysqli_query($conn,$sql)) {
	echo "Sucessfull";
}

else
echo "Try again";

$conn->close();

?>