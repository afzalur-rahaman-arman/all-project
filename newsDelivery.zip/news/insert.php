
<?php
//insert.php

          $time="";
          $num=0;
          $phonenumber="";
          $address="";
          $total=0;
$connect = mysqli_connect("localhost", "root", "", "news");
if(isset($_POST["item_name"]))
{
 $item_name = $_POST["item_name"];//newsname
 $item_code = $_POST["item_code"];//email
 $item_price = $_POST["item_price"];//tk
 $query = '';
 for($count = 0; $count<count($item_name); $count++)
 {
  $item_name_clean = mysqli_real_escape_string($connect, $item_name[$count]);
  $item_code_clean = mysqli_real_escape_string($connect, $item_code[$count]);
  $item_price_clean = mysqli_real_escape_string($connect, $item_price[$count]);
  if($item_name_clean != '' && $item_code_clean != '')
  {





        $S="select * from orders where email='$item_code'";
        $f=0;
        $t=0;
        $result=$conn->query($S);
        if ($result->num_rows>0) 
  {
          while($row=$result->fetch_assoc())
   {
        $name=$row["name"];
        $num=$row["num"];
        $phonenumber=$row['phoneNumber'];
        $address=$row['address'];
        $time=$row["req_date"];
        $total=$row['total'];
        if ($total===$item_price) 
        {
          $f=1;
          $t=$total;
        }
    }
  }



echo $t;
$tt=$tk/4;
if($f)
{
	$query = " INSERT INTO ar(news, email, total, num, name, phoneNumber, address,req_date) 
   VALUES('".$item_name_clean."','".$item_code_clean."', '".$item_price_clean."','$num','$name', '$phonenumber', '$address','$time')";
}
   
  }
 }
 if($query != '')
 {
  if(mysqli_multi_query($connect, $query))
  {
   echo 'Item Data Inserted';
  }
  else
  {
   echo 'Error';
  }
 }
 else
 {
  echo 'All Fields are Required';
 }
}
?>
