<form method="POST">
	<input type="text" name="b">
	<input type="submit" name="s">
</form>

<?php
//echo $_POST['a'];
echo $_POST['b'];
?>