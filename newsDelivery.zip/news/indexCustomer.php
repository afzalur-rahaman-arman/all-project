<?php 
  session_start(); 
  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }

  if (isset($_POST["submit"])) {
    header("location: custSubs.php");
  }
if (isset($_POST['submit1'])) {
    header("location: viewBill.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
 <title> Profile </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index1.php" >Home</a>
  <div class="navbar-brand">
     <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="indexCustomer.php" method="POST">
      <input type="submit" value="View Your Subscription" name="submit">
  </form>
<?php endif ?>
    </div>
     </div>

    <div class="navbar-brand"> 
      <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="indexCustomer.php" method="POST">
      <input type="submit" value="View Bill" name="submit1">
  </form>
<?php endif ?>
    </div>
     </div>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout </div> 
  </a>

</nav>
<br>
<br>


<?php
$conn=mysqli_connect("localhost", "root", '', "news");

$ID=$_SESSION['id'];

 $sql = "SELECT * FROM images where newsname='$ID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc(); 

        $image=  $row["image"];

echo "<img src='$image' width='200' height='200'><br>";
}
else
{
  echo "Insert Image";
}

echo "$ID <hr>";

?>

<br>
<br>
<br>
<HR>
    
</center>

</body>
</html>


