<?php (include 'server1.php')?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Online Newspaper Delivery</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="nav.css">
</head>

<body style="background-color: #00FA9A">

<nav class="topnav">
  <a class="navbar-brand" href="index.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
  <a class="navbar-brand" href="loginpage.php">Login</a>

  <a class="navbar-brand" href="userfeedback.php">Feedback</a>

  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</nav>



<br><h1><i><center>Welcome!!!<br></i></center></h1>

</div>
  <div class="header">
    <h2>Login</h2>
  </div>
     
  <form action="loginCustomer.php" method="post" >
    <?php include('errors.php'); ?>
    <div class="input-group">
        <input type="text" name="name" placeholder="Name" >
    </div>
    <div class="input-group">
        <input type="password" name="password1" placeholder="Password">
    </div>

    <div class="input-group">
      <label></label><label></label><label></label>
        <button type="submit" class="btn btn-success" name="login_user" >Login</button>
    </div>

<a href="forgetPassword.php">Forget Password</a>
    <p>
        Not yet a member? <a href="customSignUp.php">Sign up</a>
    </p>
  </form>
</body>
</html>
