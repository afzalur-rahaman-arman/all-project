<?php

$conn=mysqli_connect("localhost", "root", '', "news");

$sql="create table subscription(
 
name varchar(100), 
newsname varchar(100),
phonenumber varchar(100),
email varchar(100),
address varchar(100)
)";

if (mysqli_query($conn, $sql)) {
	echo "subscription table create successfull";
}
else
echo "Try again please";

?>