<?php
$to = "afz.cse.bgctub@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: afzctg92@gmail.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);
?>
<form action="/action_page.php" method="get">
  <input type="radio" id="male" name="gender" value="male">
  <label for="male">Male</label><br>
  <input type="radio" id="female" name="gender" value="female" checked="checked">
  <label for="female">Female</label><br>
  <input type="radio" id="other" name="gender" value="other">
  <label for="other">Other</label><br><br>
  <input type="submit" value="Submit">
</form>